import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { MongooseModule } from '@nestjs/mongoose';
import { join } from 'path';
import { AnalyticsResolver } from './resolvers/analytics.resolver';
import { Customer, CustomerSchema } from './models/customer.model';
import { Product, ProductSchema } from './models/product.model';
import { Order, OrderSchema } from './models/order.model';

@Module({
  imports: [
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      autoSchemaFile: join(process.cwd(), 'src/schema/schema.graphql'),
      sortSchema: true,
    }),
    MongooseModule.forRoot('mongodb+srv://pooja:pooja123@cluster0.sygdhbi.mongodb.net/sales'), // Replace with your MongoDB Atlas URI
    MongooseModule.forFeature([
      { name: Customer.name, schema: CustomerSchema },
      { name: Product.name, schema: ProductSchema },
      { name: Order.name, schema: OrderSchema },
    ]),
  ],
  providers: [AnalyticsResolver],
})
export class AppModule {}
