import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

@Schema()
class OrderProduct {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'Product', required: true })
  productId: string;

  @Prop({ required: true })
  quantity: number;

  @Prop({ required: true })
  priceAtPurchase: number;
}

@Schema()
export class Order extends Document {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'Customer', required: true })
  customerId: string;

  @Prop({ type: [OrderProduct], required: true })
  products: OrderProduct[];

  @Prop({ required: true })
  totalAmount: number;

  @Prop({ required: true })
  orderDate: Date;

  @Prop({ required: true, enum: ['pending', 'completed', 'cancelled'] })
  status: string;
}

export const OrderSchema = SchemaFactory.createForClass(Order); 