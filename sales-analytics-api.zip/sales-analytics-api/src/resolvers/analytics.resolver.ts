import { Resolver, Query, Args } from '@nestjs/graphql';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Order } from '../models/order.model';
import { Product } from '../models/product.model';
import { CustomerSpending, TopProduct, SalesAnalytics } from '../types/analytics.types';

@Injectable()
@Resolver()
export class AnalyticsResolver {
  constructor(
    @InjectModel(Order.name) private orderModel: Model<Order>,
    @InjectModel(Product.name) private productModel: Model<Product>,
  ) {}

  @Query(() => CustomerSpending)
  async getCustomerSpending(@Args('customerId') customerId: string) {
    const orders = await this.orderModel
      .find({ customerId, status: 'completed' })
      .sort({ orderDate: -1 });

    const totalSpent = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    const averageOrderValue = orders.length > 0 ? totalSpent / orders.length : 0;
    const lastOrderDate = orders.length > 0 ? orders[0].orderDate : null;

    return {
      customerId,
      totalSpent,
      averageOrderValue,
      lastOrderDate,
    };
  }

  @Query(() => [TopProduct])
  async getTopSellingProducts(@Args('limit') limit: number) {
    const result = await this.orderModel.aggregate([
      { $match: { status: 'completed' } },
      { $unwind: '$products' },
      {
        $group: {
          _id: '$products.productId',
          totalSold: { $sum: '$products.quantity' },
        },
      },
      { $sort: { totalSold: -1 } },
      { $limit: limit },
      {
        $lookup: {
          from: 'products',
          localField: '_id',
          foreignField: '_id',
          as: 'product',
        },
      },
      { $unwind: '$product' },
      {
        $project: {
          _id: 0,
          productId: '$_id',
          name: '$product.name',
          totalSold: 1,
        },
      },
    ]);

    return result;
  }

  @Query(() => SalesAnalytics)
  async getSalesAnalytics(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ) {
    const result = await this.orderModel.aggregate([
      {
        $match: {
          status: 'completed',
          orderDate: {
            $gte: new Date(startDate),
            $lte: new Date(endDate),
          },
        },
      },
      {
        $lookup: {
          from: 'products',
          localField: 'products.productId',
          foreignField: '_id',
          as: 'productDetails',
        },
      },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$totalAmount' },
          completedOrders: { $sum: 1 },
          categoryBreakdown: {
            $push: {
              category: { $arrayElemAt: ['$productDetails.category', 0] },
              revenue: '$totalAmount',
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          totalRevenue: 1,
          completedOrders: 1,
          categoryBreakdown: {
            $reduce: {
              input: '$categoryBreakdown',
              initialValue: [],
              in: {
                $concatArrays: [
                  '$$value',
                  [
                    {
                      category: '$$this.category',
                      revenue: '$$this.revenue',
                    },
                  ],
                ],
              },
            },
          },
        },
      },
    ]);

    return result[0] || {
      totalRevenue: 0,
      completedOrders: 0,
      categoryBreakdown: [],
    };
  }
} 