import { ObjectType, Field, ID, Float, Int } from '@nestjs/graphql';

@ObjectType()
export class CustomerSpending {
  @Field(() => ID)
  customerId: string;

  @Field(() => Float)
  totalSpent: number;

  @Field(() => Float)
  averageOrderValue: number;

  @Field(() => String, { nullable: true })
  lastOrderDate?: string;
}

@ObjectType()
export class TopProduct {
  @Field(() => ID)
  productId: string;

  @Field(() => String)
  name: string;

  @Field(() => Int)
  totalSold: number;
}

@ObjectType()
export class CategoryBreakdown {
  @Field(() => String)
  category: string;

  @Field(() => Float)
  revenue: number;
}

@ObjectType()
export class SalesAnalytics {
  @Field(() => Float)
  totalRevenue: number;

  @Field(() => Int)
  completedOrders: number;

  @Field(() => [CategoryBreakdown])
  categoryBreakdown: CategoryBreakdown[];
} 